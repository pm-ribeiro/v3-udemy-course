<template>
  <div class="notes">
    <h1>Notes</h1>
  </div>
</template>