<template>
  <RouterLink to="/">Notes</RouterLink> | 
  <RouterLink to="/stats">Stats</RouterLink>

  <RouterView />
</template>